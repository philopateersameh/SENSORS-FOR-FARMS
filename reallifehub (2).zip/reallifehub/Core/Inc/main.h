/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define SD_DET_Pin GPIO_PIN_13
#define SD_DET_GPIO_Port GPIOC
#define MAX3485__2_DE_Pin GPIO_PIN_0
#define MAX3485__2_DE_GPIO_Port GPIOA
#define MAX3485__2_RE_Pin GPIO_PIN_1
#define MAX3485__2_RE_GPIO_Port GPIOA
#define MAX3485_TX_Pin GPIO_PIN_2
#define MAX3485_TX_GPIO_Port GPIOA
#define MAX3845_RX_Pin GPIO_PIN_3
#define MAX3845_RX_GPIO_Port GPIOA
#define STM_ESP_CS_Pin GPIO_PIN_4
#define STM_ESP_CS_GPIO_Port GPIOA
#define ESP_SCK_Pin GPIO_PIN_5
#define ESP_SCK_GPIO_Port GPIOA
#define ESP_MISO_Pin GPIO_PIN_6
#define ESP_MISO_GPIO_Port GPIOA
#define ESP_MOSI_Pin GPIO_PIN_7
#define ESP_MOSI_GPIO_Port GPIOA
#define RS485_RE_Pin GPIO_PIN_4
#define RS485_RE_GPIO_Port GPIOC
#define RS485_DE_Pin GPIO_PIN_5
#define RS485_DE_GPIO_Port GPIOC
#define W5500_RST_Pin GPIO_PIN_1
#define W5500_RST_GPIO_Port GPIOB
#define W5500_INT_Pin GPIO_PIN_10
#define W5500_INT_GPIO_Port GPIOB
#define W5500_INT_EXTI_IRQn EXTI15_10_IRQn
#define W5500_CS_Pin GPIO_PIN_12
#define W5500_CS_GPIO_Port GPIOB
#define W5500_SCK_Pin GPIO_PIN_13
#define W5500_SCK_GPIO_Port GPIOB
#define W5500_MISO_Pin GPIO_PIN_14
#define W5500_MISO_GPIO_Port GPIOB
#define W5500_MOSI_Pin GPIO_PIN_15
#define W5500_MOSI_GPIO_Port GPIOB
#define max3485_DI_Pin GPIO_PIN_6
#define max3485_DI_GPIO_Port GPIOC
#define max3485_RO_Pin GPIO_PIN_7
#define max3485_RO_GPIO_Port GPIOC
#define STM_ESP_SPI_DRDY_Pin GPIO_PIN_8
#define STM_ESP_SPI_DRDY_GPIO_Port GPIOA
#define STM_ESP_SPI_DRDY_EXTI_IRQn EXTI9_5_IRQn
#define stm_tx_to_esp_rx_Pin GPIO_PIN_9
#define stm_tx_to_esp_rx_GPIO_Port GPIOA
#define stm_rx_to_esp_tx_Pin GPIO_PIN_10
#define stm_rx_to_esp_tx_GPIO_Port GPIOA
#define SHT40_SCL_Pin GPIO_PIN_6
#define SHT40_SCL_GPIO_Port GPIOB
#define SHT40_SDA_Pin GPIO_PIN_7
#define SHT40_SDA_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
